#ifndef __MOTOR_H_
#define __MOTOR_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "include.h"


#ifdef __cplusplus
}
#endif

#endif
