#ifndef __LED_H_
#define __LED_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "./SYSTEM/sys/sys.h"
void led_init(void);


#ifdef __cplusplus
}
#endif

#endif


